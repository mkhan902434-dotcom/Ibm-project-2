# House Price Prediction

## Files
- `train_model.py` - trains and saves the Linear Regression model.
- `backend/app.py` - Flask REST API.
- `frontend/ui.py` - Streamlit user interface.
- `data/house_price.csv` - sample dataset.
- `requirements.txt` - required Python packages.

## Run
```bash
pip install -r requirements.txt
python train_model.py
python backend/app.py
```

In another terminal:
```bash
streamlit run frontend/ui.py
```

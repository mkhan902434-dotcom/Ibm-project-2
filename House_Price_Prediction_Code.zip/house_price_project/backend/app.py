from flask import Flask, request, jsonify
from pathlib import Path
import joblib

app = Flask(__name__)

MODEL_PATH = Path(__file__).resolve().parent.parent / "model" / "model.pkl"
model = joblib.load(MODEL_PATH)

@app.get("/")
def home():
    return jsonify({"message": "House Price Prediction API is running"})

@app.post("/predict")
def predict():
    data = request.get_json(silent=True) or {}

    try:
        area = float(data["area"])
        rooms = float(data["rooms"])
    except (KeyError, TypeError, ValueError):
        return jsonify({"error": "Provide numeric area and rooms."}), 400

    prediction = model.predict([[area, rooms]])[0]

    return jsonify({
        "area": area,
        "rooms": rooms,
        "predicted_price": float(prediction)
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

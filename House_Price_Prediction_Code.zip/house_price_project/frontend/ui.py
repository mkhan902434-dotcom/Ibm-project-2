import streamlit as st
import requests

st.set_page_config(page_title="House Price Prediction", page_icon="🏠")

st.title("🏠 House Price Prediction")
st.write("Predict a house price using area and number of rooms.")

area = st.number_input("Area (sq ft)", min_value=1.0, value=1000.0, step=50.0)
rooms = st.number_input("Number of Rooms", min_value=1.0, value=2.0, step=1.0)

if st.button("Predict Price"):
    try:
        response = requests.post(
            "http://127.0.0.1:5000/predict",
            json={"area": area, "rooms": rooms},
            timeout=10
        )

        if response.ok:
            result = response.json()
            st.success(f"Predicted House Price: {result['predicted_price']:.2f}")
        else:
            st.error(response.json().get("error", "Prediction failed."))
    except requests.RequestException:
        st.error("Flask backend is not running. Start backend/app.py first.")

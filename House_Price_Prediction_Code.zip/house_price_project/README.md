# House Price Prediction

Full-stack ML project using Linear Regression, Flask and Streamlit.

## Run

```bash
pip install -r requirements.txt
python train_model.py
python backend/app.py
```

In another terminal:

```bash
streamlit run frontend/ui.py
```

Inputs:
- area (sq ft)
- rooms

Output:
- predicted house price
